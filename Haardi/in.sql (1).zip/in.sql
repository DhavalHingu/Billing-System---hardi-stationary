--
-- Database: `in`
--

-- --------------------------------------------------------

--
-- Table structure for table `information`
--

CREATE TABLE `information` (
  `no` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `product` varchar(800) DEFAULT NULL,
  `inf` varchar(800) DEFAULT NULL,
  `total` int(30) NOT NULL,
  `Discounted` int(30) NOT NULL,
  `cost` varchar(1500) NOT NULL,
  `qty` varchar(1500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `information`
--

INSERT INTO `information` (`no`, `name`, `date`, `product`, `inf`, `total`, `Discounted`, `cost`, `qty`) VALUES
(1, 'Dhaval', '2017-05-30', '		      		      		      		      		      		      		      		      hh,		      		      		      		      		      		      		      		      ItemName,		      		      		      		      		      		      		      		      ItemName,		      		      		      		      		      		      Item Name,		      		      		      		      book,                              book,                              j,                    book,                    sdfghjkl,          dfghjk,          ertgyujk,          dfghjk,          dfghj,          fghjk,          3,          		                book,		                          book,		                          j', 'hh,Description,Description,Description,natraj,r,j,kk,erfgthyjklftgyhujikl,dfghjk,fghjk,ertyui,fghj,edfghjk,3,r,r,j', 6543, 6543, '20,40,80,20,50,10,5,5,88,30,4,23,7,5,4,10,10,5', '5,2,5,5,2,5,2,6,60,5,3,4,1,2,3,5,5,2');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `name` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`name`, `password`) VALUES
('dhaval', 'dhaval123');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product`) VALUES
('pen'),
('2'),
('pen'),
('1'),
('kk'),
('lllll'),
(''),
(''),
('ppp,kkk,hhh');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `information`
--
ALTER TABLE `information`
  ADD PRIMARY KEY (`no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `information`
--
ALTER TABLE `information`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
